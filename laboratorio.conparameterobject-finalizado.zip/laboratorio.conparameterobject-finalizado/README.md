# Laboratorio.ConParameterObject
Este laboratorio nos permite practicar el diseño con parameter objects y así reducimos la cantidad de parámetros.

[![Build status](https://ci.appveyor.com/api/projects/status/y4shmfmv684ucu4m?svg=true)](https://ci.appveyor.com/project/oscarcenteno/laboratorio-conparameterobject)
