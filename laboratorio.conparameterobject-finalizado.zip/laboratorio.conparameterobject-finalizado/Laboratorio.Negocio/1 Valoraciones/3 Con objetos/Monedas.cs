﻿namespace Negocio.Valoraciones.ConObjetos
{
    public enum Monedas
    {
        Colon,
        USDolar,
        UDEs
    }
}
